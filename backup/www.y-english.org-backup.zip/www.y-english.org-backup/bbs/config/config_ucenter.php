<?php


define('UC_CONNECT', 'mysql');

define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'root');
define('UC_DBPW', 'root3306');
define('UC_DBNAME', 'yunbbs');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`yunbbs`.pre_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'tc57i2F0C0SeC6W3ffUe12Qcl4BcMef6jcJbF3b8v4P3Bb76N0Ta4a32L3DaLcc9');
define('UC_API', 'http://www.y-english.org/bbs/uc_server');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);
?>