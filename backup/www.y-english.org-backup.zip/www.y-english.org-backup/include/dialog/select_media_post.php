<?php
include_once(dirname(__FILE__).'/config.php');
$cfg_softtype = $cfg_mediatype;
$cfg_soft_dir = $cfg_other_medias;
$bkurl = 'select_media.php';
$uploadmbtype = "��ý���ļ�����";
require_once(dirname(__FILE__)."/select_soft_post.php");
?>