// JavaScript Document
//圆角div加载文件
$(document).ready(function(){
	$(".roundcorner").corner("round 5px");
});